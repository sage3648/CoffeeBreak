document.addEventListener('DOMContentLoaded', function() {
    $("button").mouseenter(function(){
        $(this).css('border','1px solid black');
        $(this).css('background', 'lightblue');
    });
    $("button").mouseleave(function(){
        $(this).css('border','0.5px solid black');
        $(this).css('background', 'lightskyblue');
    });
    var checkPageButton = document.getElementById('setReminder');
    var messageTextArea = document.getElementById('message');
    checkPageButton.addEventListener('click', function() {
      $("#message").val("change");
    }, false);
  }, false);